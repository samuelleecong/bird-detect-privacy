# Bird Detect — Reviewer Test Kit

A small bundle of public-domain bird photographs that App Store reviewers
(and anyone else) can use to verify Bird Detect end-to-end without needing
their own photo library.

## Contents

`images/` — 7 JPEGs of common bird species, deliberately varied in:

- **Subject count:** single bird (cardinal, blue jay, robin, eagle, goose) and multi-bird (mallard pair, parrot pair)
- **Bird size in frame:** close-up portraits and full-body shots
- **Backgrounds:** branches, water, sky, ground
- **File size:** ~190 KB to ~7 MB — exercises both fast and slow paths

| File | Subject | Source |
|---|---|---|
| `01_amazon_parrots.jpg` | Two Amazon parrots (multi-bird grouping test) | Wikimedia Commons (public domain / CC) |
| `02_blue_jay.jpg` | Single blue jay perched on branch | Wikimedia Commons |
| `03_american_robin.jpg` | Single American robin on grass | Wikimedia Commons |
| `04_mallard_pair.jpg` | Mallard pair on water (multi-bird grouping test) | Wikimedia Commons |
| `05_bald_eagle.jpg` | Single bald eagle, large frame | Wikimedia Commons |
| `06_canada_goose.jpg` | Single Canada goose, full body | Wikimedia Commons |
| `07_cardinal_male.jpg` | Single male northern cardinal in tree | Wikimedia Commons |

All images are licensed for unrestricted use under public-domain or Creative
Commons terms. They are bundled here purely so reviewers and testers do not
need to provide their own bird photographs.

## How a Reviewer Should Use This Kit

There are two paths the app supports — testing both confirms the full feature surface.

### Path A — Photos Library (recommended; exercises the wedge feature)

1. Open **Apple Photos.app**.
2. Drag the entire `ReviewerTestKit/images/` folder into the Photos window. Apple Photos imports them as a new "Imported" album under "My Albums."
3. Launch **Bird Detect**.
4. Click through the three onboarding screens.
5. Grant Photos library access when prompted.
6. Click **Select Album** in the main window, choose the imported album, and confirm.
7. Click **Process All**.
8. After ~5–15 seconds, the grid view shows all detected birds, grouped by source image.
9. Click into any grouped result to see detail view + the **Apply to Photos** button.
10. Tap "Apply to Photos" — the cropped version replaces the source in Photos.app as a reversible edit. You can verify by opening Photos.app and choosing the photo's Edit menu → Revert to Original.

### Path B — Filesystem Folder

1. Launch **Bird Detect**.
2. Click through onboarding.
3. Click **Select Folder**.
4. Navigate to and choose `ReviewerTestKit/images/`.
5. Click **Process All**.
6. Crops are written to the auto-created output folder (path shown in the status bar). Open it in Finder to verify.

## Verifying the Free Tier and Paywall

The kit only contains 7 images, which stays under the 50-photo free-tier
cap, so the paywall does not auto-trigger. To verify the paywall path:

- **Toolbar:** click the tinted **Unlock $24.99** button next to the "Free"
  pill in the window's trailing toolbar. The paywall sheet appears.
- **Settings:** open Settings (`Cmd+,`) → **Account** tab → click
  **Unlock for $24.99**. Same sheet appears.
- The sheet exposes **Restore Purchase** as a Cmd-required text link in
  the bottom controls.

For sandbox-purchase testing the project ships a `Configuration.storekit`
file. Activate it in the run scheme: **Edit Scheme → Run → Options → StoreKit
Configuration → `Configuration.storekit`**. Sandbox accounts can then
complete a fake purchase to flip the entitlement.

## Verifying Privacy

Bird Detect does no network I/O during detection or cropping. To verify:

```bash
# Watch the app's network connections live (requires admin)
sudo lsof -i -P -n -p $(pgrep -x bird_detect)
```

Expected: zero connections during processing. Only StoreKit talks to
Apple's servers (`itunes.apple.com`, `buy.itunes.apple.com`) — and only
when the user actively initiates a purchase or a Restore.

You can also use Little Snitch or the Network tab in Activity Monitor to
confirm the same: detection runs offline, end to end.

## Image Sources & Attribution

All seven images were sourced from Wikimedia Commons. Wikimedia Commons
hosts user-contributed media that is freely licensed; the specific
licensing for each image is shown on the Commons page for that file.

These photos are not original work of the Bird Detect developer. They are
included strictly for the convenience of testers and reviewers, not as
proprietary content.

If a reviewer or any other party prefers not to use bundled images, the
app works with any photos the user supplies — there is nothing
load-bearing about this kit beyond saving setup time.

## Removing the Kit From a Photos Library

If the reviewer imported the kit into Photos.app and wants to remove it
afterward:

1. Open Photos.app.
2. Find the imported album under My Albums.
3. Select all images, press Delete.
4. Empty the Recently Deleted album to remove permanently.

This is a standard Photos.app operation and unrelated to Bird Detect.
